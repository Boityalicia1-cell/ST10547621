package quickchat;

import java.util.Scanner;

/** Console application for Part 1: registration and login. */
public class Main {
    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        Login account = register();
        login(account);
        System.out.println("You have successfully completed the registration and login section.");
    }

    private static Login register() {
        System.out.println("=== QuickChat Registration ===");
        System.out.print("First name: ");
        String firstName = input.nextLine().trim();
        System.out.print("Last name: ");
        String lastName = input.nextLine().trim();

        while (true) {
            System.out.print("Username: ");
            String username = input.nextLine().trim();
            System.out.print("Password: ");
            String password = input.nextLine();
            System.out.print("Cell phone number (for example +27838968976): ");
            String cell = input.nextLine().trim();

            Login account = new Login(firstName, lastName, username, password, cell);
            System.out.println(account.usernameMessage());
            System.out.println(account.passwordMessage());
            System.out.println(account.cellPhoneMessage());

            if (account.checkUserName() && account.checkPasswordComplexity()
                    && account.checkCellPhoneNumber()) {
                System.out.println(account.registerUser());
                return account;
            }
            System.out.println("Please try again.\n");
        }
    }

    private static void login(Login account) {
        System.out.println("\n=== QuickChat Login ===");
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Username: ");
            String username = input.nextLine().trim();
            System.out.print("Password: ");
            String password = input.nextLine();
            loggedIn = account.loginUser(username, password);
            System.out.println(account.returnLoginStatus(loggedIn));
        }
    }
}
