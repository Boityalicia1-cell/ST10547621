QUICKCHAT PART 1 - NOTEPAD VERSION

Files: quickchat\Main.java and quickchat\Login.java

IMPORTANT: Notepad is only for editing code. To run Java, install a JDK first.

RUNNING ON WINDOWS (after installing a JDK):
1. Extract this folder.
2. Open the extracted folder in File Explorer.
3. Click the address bar, type cmd, and press Enter.
4. Run: javac quickchat\*.java
5. Run: java quickchat.Main

Keep the files inside the quickchat folder because they begin with package quickchat;

Open any .java file with Notepad by right-clicking it, choosing Open with, then Notepad.
When saving in Notepad, select Save as type: All files and keep the exact .java filename.
