package quickchat;

import java.util.regex.Pattern;

/*
 * Login.java - QuickChat Part 1 (registration and login)
 *
 * References:
 * - The cell phone regex follows the E.164 layout: a "+", a country code of
 *   1 to 3 digits and then the rest of the number (ITU-T, 2026; Twilio, n.d.).
 * - How to compile and use a regex in Java: Oracle (n.d.) Pattern class.
 * Full reference list is in REFERENCES.md
 */
public class Login {

    // + then 1-3 digit country code then 1-10 digits (brief says max ten characters for the number)
    // I used \\d because backslashes have to be doubled inside a Java string (Oracle, n.d.)
    private static final Pattern CELL_PATTERN = Pattern.compile("^\\+\\d{1,3}\\d{1,10}$");

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhone;

    public Login(String firstName, String lastName, String username,
                 String password, String cellPhone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhone = cellPhone;
    }

    // username needs an underscore and can't be longer than 5 characters
    public boolean checkUserName() {
        if (username == null) {
            return false;
        }
        return username.contains("_") && username.length() <= 5;
    }

    // password: 8+ characters, one capital, one number, one special character
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetter(c)) {
                // not a letter and not a digit so it must be a special character
                hasSpecial = true;
            }
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    // uses the regex above, so "08966553" fails (no +country code)
    public boolean checkCellPhoneNumber() {
        if (cellPhone == null) {
            return false;
        }
        return CELL_PATTERN.matcher(cellPhone).matches();
    }

    // ---- messages (kept in their own methods so the unit tests can check them) ----

    public String usernameMessage() {
        if (checkUserName()) {
            return "Username successfully captured.";
        }
        return "Username is not correctly formatted; please ensure that your username "
                + "contains an underscore and is no more than five characters in length.";
    }

    public String passwordMessage() {
        if (checkPasswordComplexity()) {
            return "Password successfully captured.";
        }
        return "Password is not correctly formatted; please ensure that the password "
                + "contains at least eight characters, a capital letter, a number, and "
                + "a special character.";
    }

    public String cellPhoneMessage() {
        if (checkCellPhoneNumber()) {
            return "Cell number successfully captured.";
        }
        return "Cell number is incorrectly formatted or does not contain an international "
                + "code; please correct the number and try again.";
    }

    // username is checked first, then the password
    public String registerUser() {
        if (!checkUserName()) {
            return usernameMessage();
        }
        if (!checkPasswordComplexity()) {
            return passwordMessage();
        }
        return "User has been registered successfully.";
    }

    // compares what was typed in to what was saved when the user registered
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (username == null || password == null) {
            return false;
        }
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    public String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
