package quickchat;

import java.util.Scanner;

/** Console application for Part 2: sending, disregarding and storing messages. */
public class Main {
    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        Login account = register();
        login(account);

        System.out.println("\nWelcome to QuickChat.");
        int maximumMessages = readNumber("How many messages do you want to enter? ", 1, 1000);
        int messagesEntered = 0;
        boolean running = true;

        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            int option = readNumber("Choose an option: ", 1, 3);

            switch (option) {
                case 1 -> {
                    if (messagesEntered >= maximumMessages) {
                        System.out.println("You have already entered all " + maximumMessages + " messages.");
                    } else {
                        handleOneMessage(messagesEntered);
                        messagesEntered++;
                        if (messagesEntered == maximumMessages) {
                            System.out.println("\nAll messages entered.");
                            System.out.println("Total messages sent: " + Message.returnTotalMessages());
                        }
                    }
                }
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> {
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    running = false;
                }
                default -> System.out.println("Please choose a valid option.");
            }
        }
    }

    private static void handleOneMessage(int messageNumber) {
        String recipient;
        while (true) {
            System.out.print("Recipient cell number (for example +27718693002): ");
            recipient = input.nextLine().trim();
            Message check = new Message(messageNumber, recipient, "check");
            String result = check.checkRecipientCell();
            System.out.println(result);
            if (result.startsWith("Cell phone number successfully")) {
                break;
            }
        }

        String messageText;
        while (true) {
            System.out.print("Message (max 250 characters): ");
            messageText = input.nextLine().trim();
            if (messageText.isEmpty()) {
                System.out.println("The message can't be empty.");
            } else if (messageText.length() > 250) {
                System.out.println("Please enter a message of less than 250 characters.");
            } else {
                System.out.println(Message.checkMessageLength(messageText));
                break;
            }
        }

        Message message = new Message(messageNumber, recipient, messageText);
        System.out.println(message.messageIDMessage());
        System.out.println("\n1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        int choice = readNumber("Choose an option: ", 1, 3);
        System.out.println(message.sentMessage(choice));

        if (choice == 1) {
            System.out.println("\n" + message.fullDetails());
        } else if (choice == 2) {
            System.out.print("Enter 0 to delete this message: ");
            if (input.nextLine().trim().equals("0")) {
                System.out.println("Message deleted.");
            } else {
                System.out.println("Message was not deleted but it was not sent either.");
            }
        }
    }

    private static Login register() {
        System.out.println("=== QuickChat Registration ===");
        System.out.print("First name: ");
        String firstName = input.nextLine().trim();
        System.out.print("Last name: ");
        String lastName = input.nextLine().trim();

        while (true) {
            System.out.print("Username: ");
            String username = input.nextLine().trim();
            System.out.print("Password: ");
            String password = input.nextLine();
            System.out.print("Cell phone number (for example +27838968976): ");
            String cell = input.nextLine().trim();

            Login account = new Login(firstName, lastName, username, password, cell);
            System.out.println(account.usernameMessage());
            System.out.println(account.passwordMessage());
            System.out.println(account.cellPhoneMessage());
            if (account.checkUserName() && account.checkPasswordComplexity()
                    && account.checkCellPhoneNumber()) {
                System.out.println(account.registerUser());
                return account;
            }
            System.out.println("Please try again.\n");
        }
    }

    private static void login(Login account) {
        System.out.println("\n=== QuickChat Login ===");
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Username: ");
            String username = input.nextLine().trim();
            System.out.print("Password: ");
            String password = input.nextLine();
            loggedIn = account.loginUser(username, password);
            System.out.println(account.returnLoginStatus(loggedIn));
        }
    }

    private static int readNumber(String prompt, int minimum, int maximum) {
        while (true) {
            System.out.print(prompt);
            try {
                int number = Integer.parseInt(input.nextLine().trim());
                if (number >= minimum && number <= maximum) {
                    return number;
                }
            } catch (NumberFormatException ignored) {
                // Show the validation message below when input is not a number.
            }
            System.out.println("Please enter a valid number.");
        }
    }
}
