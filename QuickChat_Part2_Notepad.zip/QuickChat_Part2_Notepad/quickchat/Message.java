package quickchat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Represents one QuickChat message. The methods are kept small so each part
 * can be tested separately, as required by the Programming 1A brief.
 * JSON format and escaping are based on RFC 8259 (Bray, 2017).
 */
public class Message {
    private static final Pattern CELL_PATTERN = Pattern.compile("^\\+\\d{1,3}\\d{8,10}$");
    private static final Random RANDOM = new Random();
    private static final List<Message> SENT_MESSAGES = new ArrayList<>();
    private static final List<Message> DISREGARDED_MESSAGES = new ArrayList<>();
    private static final List<Message> STORED_MESSAGES = new ArrayList<>();
    private static int numMessagesSent;
    private static String jsonFile = "messages.json";

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private final String messageHash;
    private String status = "Pending";

    public Message(int messageNumber, String recipient, String message) {
        this(makeMessageID(), messageNumber, recipient, message);
    }

    public Message(String messageID, int messageNumber, String recipient, String message) {
        this.messageID = messageID == null ? "" : messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient == null ? "" : recipient;
        this.message = message == null ? "" : message;
        this.messageHash = createMessageHash();
    }

    private static String makeMessageID() {
        return String.format("%010d", RANDOM.nextLong(10_000_000_000L));
    }

    public boolean checkMessageID() {
        return !messageID.isEmpty() && messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (CELL_PATTERN.matcher(recipient).matches()) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }

    public static String checkMessageLength(String text) {
        if (text == null) return "Please enter a message.";
        int extraCharacters = text.length() - 250;
        if (extraCharacters > 0) {
            return "Message exceeds 250 characters by " + extraCharacters + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    public String createMessageHash() {
        String trimmed = message.trim();
        String[] words = trimmed.isEmpty() ? new String[]{"", ""} : trimmed.split("\\s+");
        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        String firstTwo = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        return (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // 1 = send, 2 = disregard, 3 = store for later.
    public String sentMessage(int choice) {
        if (choice == 1) {
            status = "Sent";
            SENT_MESSAGES.add(this);
            numMessagesSent++;
            return "Message successfully sent.";
        }
        if (choice == 2) {
            status = "Disregarded";
            DISREGARDED_MESSAGES.add(this);
            return "Press 0 to delete the message.";
        }
        if (choice == 3) {
            status = "Stored";
            if (storeMessage()) {
                STORED_MESSAGES.add(this);
                return "Message successfully stored.";
            }
            return "Message could not be stored.";
        }
        return "Invalid option.";
    }

    public static String printMessages() {
        if (SENT_MESSAGES.isEmpty()) return "No messages have been sent.";
        StringBuilder result = new StringBuilder();
        for (Message item : SENT_MESSAGES) result.append(item.fullDetails()).append("\n\n");
        return result.toString().trim();
    }

    public static int returnTotalMessages() { return numMessagesSent; }

    public String fullDetails() {
        return "Message ID: " + messageID + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient + "\nMessage: " + message;
    }

    public String messageIDMessage() { return "Message ID generated: " + messageID; }

    public boolean storeMessage() {
        try {
            Path path = Paths.get(jsonFile);
            List<Message> existing = readStoredMessages();
            // Avoid adding the same message twice if this method is called again.
            boolean alreadyThere = existing.stream().anyMatch(item -> item.messageID.equals(messageID));
            if (!alreadyThere) existing.add(this);
            StringBuilder json = new StringBuilder("[\n");
            for (int i = 0; i < existing.size(); i++) {
                Message item = existing.get(i);
                json.append("  {\n")
                    .append("    \"messageID\": \"").append(escapeJson(item.messageID)).append("\",\n")
                    .append("    \"messageHash\": \"").append(escapeJson(item.messageHash)).append("\",\n")
                    .append("    \"messageNumber\": ").append(item.messageNumber).append(",\n")
                    .append("    \"recipient\": \"").append(escapeJson(item.recipient)).append("\",\n")
                    .append("    \"message\": \"").append(escapeJson(item.message)).append("\",\n")
                    .append("    \"status\": \"").append(escapeJson(item.status)).append("\"\n  }");
                if (i < existing.size() - 1) json.append(',');
                json.append('\n');
            }
            json.append(']');
            Path parent = path.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.writeString(path, json.toString());
            return true;
        } catch (IOException | RuntimeException exception) {
            return false;
        }
    }

    /* Reads message objects from the JSON file written by this class. */
    public static List<Message> readStoredMessages() {
        List<Message> result = new ArrayList<>();
        Path path = Paths.get(jsonFile);
        if (!Files.exists(path)) return result;
        try {
            String json = Files.readString(path);
            Matcher objects = Pattern.compile("\\{(.*?)\\}", Pattern.DOTALL).matcher(json);
            while (objects.find()) {
                String object = objects.group(1);
                String id = jsonValue(object, "messageID");
                String hash = jsonValue(object, "messageHash");
                String numberText = jsonNumber(object, "messageNumber");
                String recipient = jsonValue(object, "recipient");
                String text = jsonValue(object, "message");
                String status = jsonValue(object, "status");
                if (id != null && recipient != null && text != null) {
                    int number = numberText == null ? result.size() : Integer.parseInt(numberText);
                    Message item = new Message(id, number, recipient, text);
                    item.status = status == null ? "Stored" : status;
                    result.add(item);
                }
            }
        } catch (IOException exception) {
            // Return the messages read so far; callers can show an empty result.
        }
        return result;
    }

    private static String jsonNumber(String object, String key) {
        Matcher matcher = Pattern.compile("\\\"" + Pattern.quote(key) + "\\\"\\s*:\\s*(\\d+)").matcher(object);
        return matcher.find() ? matcher.group(1) : null;
    }

    public static void resetStoredMessagesOnly() {
        STORED_MESSAGES.clear();
        try { Files.writeString(Paths.get(jsonFile), "[]"); } catch (IOException ignored) { }
    }

    private static String jsonValue(String object, String key) {
        Matcher matcher = Pattern.compile("\\\"" + Pattern.quote(key)
                + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"").matcher(object);
        return matcher.find() ? unescapeJson(matcher.group(1)) : null;
    }

    private static String escapeJson(String text) {
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"' -> result.append("\\\"");
                case '\\' -> result.append("\\\\");
                case '\n' -> result.append("\\n");
                case '\r' -> result.append("\\r");
                case '\t' -> result.append("\\t");
                default -> { if (c < 0x20) result.append(String.format("\\u%04x", (int) c)); else result.append(c); }
            }
        }
        return result.toString();
    }

    private static String unescapeJson(String text) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\\' && i + 1 < text.length()) {
                char next = text.charAt(++i);
                switch (next) {
                    case 'n' -> result.append('\n');
                    case 'r' -> result.append('\r');
                    case 't' -> result.append('\t');
                    case '"' -> result.append('"');
                    case '\\' -> result.append('\\');
                    case 'u' -> {
                        if (i + 4 < text.length()) {
                            result.append((char) Integer.parseInt(text.substring(i + 1, i + 5), 16));
                            i += 4;
                        }
                    }
                    default -> result.append(next);
                }
            } else result.append(c);
        }
        return result.toString();
    }

    public static List<Message> getSentMessages() { return new ArrayList<>(SENT_MESSAGES); }
    public static List<Message> getDisregardedMessages() { return new ArrayList<>(DISREGARDED_MESSAGES); }
    public static List<Message> getStoredMessages() { return new ArrayList<>(STORED_MESSAGES); }
    public static void setJsonFile(String fileName) { jsonFile = fileName; }
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getStatus() { return status; }
    public void setStatus(String value) { status = value; }

    public static void resetMessages() {
        numMessagesSent = 0;
        SENT_MESSAGES.clear();
        DISREGARDED_MESSAGES.clear();
        STORED_MESSAGES.clear();
    }
}
